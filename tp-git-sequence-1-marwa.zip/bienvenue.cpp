// Programme qui affiche un message de bienvenue
#include <iostream>

int main()
{
    std::cout << "Bienvenue !" << std::endl;
    return 0;
}

